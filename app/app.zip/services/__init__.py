# app/services/__init__.py
from .auth_service import AuthService

__all__ = ["AuthService", "auth_service"]
