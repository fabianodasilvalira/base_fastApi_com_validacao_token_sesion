from fastapi import BackgroundTasks
from loguru import logger
from typing import List

# Para um envio de e-mail real, você precisará instalar a biblioteca 'fastapi-mail'.
# Exemplo de instalação: pip install fastapi-mail
from fastapi_mail import FastMail, MessageSchema, ConnectionConfig

from app.core.config.settings import settings


# ✅ A configuração agora lê as variáveis diretamente do objeto 'settings'
#    que foi preenchido a partir do seu arquivo .env
conf = ConnectionConfig(
    MAIL_USERNAME=settings.MAIL_USERNAME,
    MAIL_PASSWORD=settings.MAIL_PASSWORD,
    MAIL_FROM=settings.MAIL_FROM,
    MAIL_PORT=settings.MAIL_PORT,
    MAIL_SERVER=settings.MAIL_SERVER,
    MAIL_STARTTLS=settings.MAIL_TLS,
    MAIL_SSL_TLS=settings.MAIL_SSL, # Usa a variável MAIL_SSL do .env
    USE_CREDENTIALS=True,
    VALIDATE_CERTS=True
)

class EmailService:

    @staticmethod
    async def send_password_reset_email(email_to: str, token: str, background_tasks: BackgroundTasks):
        """
        Envia um e-mail de redefinição de senha para o usuário.

        Args:
            email_to: O e-mail do destinatário.
            token: O token de redefinição de senha a ser incluído no link.
            background_tasks: Gerenciador de tarefas em segundo plano do FastAPI.
        """
        # Constrói a URL que o usuário irá clicar no e-mail.
        # Agora lê 'FRONTEND_URL' e 'PASSWORD_RESET_TOKEN_EXPIRE_MINUTES' do objeto settings.
        reset_url = f"{settings.FRONTEND_URL}/auth/reset-password?token={token}"

        subject = "Redefinição de Senha"

        # Corpo do e-mail em HTML.
        html_content = f"""
        <html>
            <body>
                <h2>Olá,</h2>
                <p>Você solicitou a redefinição da sua senha. Clique no link abaixo para criar uma nova senha:</p>
                <p><a href="{reset_url}" target="_blank">Redefinir minha senha</a></p>
                <p>Se você não solicitou isso, por favor, ignore este e-mail.</p>
                <p>O link expirará em {settings.PASSWORD_RESET_TOKEN_EXPIRE_MINUTES} minutos.</p>
                <br>
                <p>Atenciosamente,</p>
                <p>Equipe do Sistema</p>
            </body>
        </html>
        """

        # --- Simulação de Envio de E-mail ---
        # Esta simulação continuará funcionando, mas a implementação real abaixo também está pronta.
        logger.info("--- SIMULAÇÃO DE ENVIO DE E-MAIL ---")
        logger.info(f"Para: {email_to}")
        logger.info(f"Assunto: {subject}")
        logger.info(f"Link de redefinição: {reset_url}")
        logger.info("--- FIM DA SIMULAÇÃO ---")

        # --- Implementação Real com fastapi-mail (descomente para usar) ---
        message = MessageSchema(
            subject=subject,
            recipients=[email_to],
            body=html_content,
            subtype="html"
        )

        fm = FastMail(conf)
        background_tasks.add_task(fm.send_message, message)


# Instância global do serviço
email_service = EmailService()
