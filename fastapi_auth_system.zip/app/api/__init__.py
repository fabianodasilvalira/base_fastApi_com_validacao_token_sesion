# app/api/__init__.py
from . import v1
from . import deps

__all__ = ["v1", "deps"]
